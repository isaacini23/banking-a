# Complete Mobile Banking Template(Dark+Light Theme) built with ♥️ with Flutter 🔥

Inspired by [Twinkle Creative](https://dribbble.com/shots/16369224-Banking-Mobile-App).

<p float="center">
  <img src="https://github.com/martinoyovo/flutter-banking-app/blob/main/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%2013%20-%202022-01-18%20at%2003.22.23.png" width="190"/>
  <img src="https://raw.githubusercontent.com/martinoyovo/flutter-banking-app/main/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%2012%20Pro%20Max%20-%202021-09-13%20at%2019.12.02.png" width="190"/>
  <img src="https://github.com/martinoyovo/flutter-banking-app/blob/main/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%2013%20-%202022-01-18%20at%2003.22.11.png" width="190"/>
  <img src="https://raw.githubusercontent.com/martinoyovo/flutter-banking-app/main/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%2012%20Pro%20Max%20-%202021-10-11%20at%2019.09.37.png" width="190"/>
  <img src="https://github.com/martinoyovo/flutter-banking-app/blob/main/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%2013%20-%202022-01-18%20at%2003.22.27.png" width="190"/>
  <img src="https://raw.githubusercontent.com/martinoyovo/flutter-banking-app/main/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%2012%20Pro%20Max%20-%202021-10-11%20at%2019.09.30.png" width="190"/>
  <img src="https://github.com/martinoyovo/flutter-banking-app/blob/main/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%2013%20-%202022-01-18%20at%2003.31.07.png" width="190"/>
  <img src="https://raw.githubusercontent.com/martinoyovo/flutter-banking-app/main/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%2012%20Pro%20Max%20-%202021-10-11%20at%2019.09.48.png" width="190"/>
  <img src="https://raw.githubusercontent.com/martinoyovo/flutter-banking-app/main/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%2012%20Pro%20Max%20-%202021-10-11%20at%2019.09.52.png" width="190"/>
</p>

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
